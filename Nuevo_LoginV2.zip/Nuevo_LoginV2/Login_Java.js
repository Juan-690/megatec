const signUpButton = document.getElementById("signUp");
const signInButton = document.getElementById("signIn");
const container = document.getElementById("container");

// Abrir formulario de registro
signUpButton.addEventListener("click", () => {
    container.classList.add("right-panel-active");
});

// Volver al formulario de login
signInButton.addEventListener("click", () => {
    container.classList.remove("right-panel-active");
});